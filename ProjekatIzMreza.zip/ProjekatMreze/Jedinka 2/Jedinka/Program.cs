﻿using System;

namespace Jedinka
{
    class Program
    {
        static void Main(string[] args)
        {
            JedinkaClient client = new JedinkaClient(2, 9, 0, "127.0.0.1", 50032, "127.0.0.1", 50005);
            client.Run();

        }
    }
}
