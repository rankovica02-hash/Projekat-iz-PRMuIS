﻿using System;

namespace ServerUDP
{
    class Program
    {
        static void Main(string[] args)
        {
            int port = 50032;

            UdpServer server = new UdpServer(port);
            server.Run();
        }
    }
}
