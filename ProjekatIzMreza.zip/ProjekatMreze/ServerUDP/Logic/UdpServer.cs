﻿using ServerUDP.Logic;
using Shared.Models;
using Shared.Net;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace ServerUDP
{
    public class UdpServer
    {
        private Socket serverSocket;
        private IPEndPoint localEndPoint;
        private Lavirint lavirint;
        private Dictionary<int, char> clientSlova = new Dictionary<int, char>();
        private Dictionary<int, Koordinate> clientPozicije = new Dictionary<int, Koordinate>();
        private char nextSlovo = 'A';

        private int port;

        public UdpServer(int port)
        {
            this.port = port;

            lavirint = new Lavirint();

            serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            localEndPoint = new IPEndPoint(IPAddress.Any, port);
            serverSocket.Bind(localEndPoint);

            serverSocket.Blocking = false;
        }

        public void Run()
        {
            Console.Clear();
            Console.CursorVisible = false;

            while (true)
            {
                //multipleksiranje
                List<Socket> readList = new List<Socket>();
                readList.Add(serverSocket);

                Socket.Select(readList, null, null, 500 * 1000); //0.5s

                if (readList.Count == 0)
                {
                    continue;
                }
                
                ObradiJedanZahtev();
            }
        }

        private void ObradiJedanZahtev()
        {
            byte[] buffer = new byte[256];
            EndPoint senderEP = new IPEndPoint(IPAddress.Any, 0); //adresa posiljaova

            int bytes = 0;
            try
            {
                bytes = serverSocket.ReceiveFrom(buffer, ref senderEP);
            }
            catch (SocketException ex)
            {
                if (ex.SocketErrorCode == SocketError.WouldBlock)
                    return;
                return;
            }

            string msg = System.Text.Encoding.UTF8.GetString(buffer, 0, bytes).Trim();

            int id, x, y;
            if (!ParseIdXY(msg, out id, out x, out y))
            {
                //provera formata
                byte[] err = Encoding.UTF8.GetBytes("ERR format je: ID X Y");
                serverSocket.SendTo(err, senderEP);
                return;
            }
            int key = id;

            //dodeli slovo ako je prvi put
            if (!clientSlova.ContainsKey(key))
            {
                clientSlova[key] = nextSlovo;
                nextSlovo++;
            }

            //zapamti poslednju poziciju
            clientPozicije[key] = new Koordinate(x, y);

            Console.CursorVisible = false;
            Console.SetCursorPosition(0, 0);
            lavirint.IspisiLavirint(clientPozicije, clientSlova);


            int statusY = Lavirint.Visina + 1;
            Console.SetCursorPosition(0, statusY);

            string status = "Zahtev od: " + senderEP + " => ID=" + id + " (" + x + "," + y + "), Slovo: " + clientSlova[key];
            Console.Write(status.PadRight(Console.WindowWidth - 1));

            int logY = Lavirint.Visina + 2;
            Console.SetCursorPosition(0, logY);


            Okolina ok = lavirint.VratiOkolinu3x3(x, y);


            byte[] payload = SerializeOkolina(ok);
            serverSocket.SendTo(payload, senderEP);
        }

        private bool ParseIdXY(string msg, out int id, out int x, out int y)
        {
            id = 0; x = 0; y = 0;

            string[] parts = msg.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length != 3) return false;

            if (!int.TryParse(parts[0], out id)) return false;
            if (!int.TryParse(parts[1], out x)) return false;
            if (!int.TryParse(parts[2], out y)) return false;

            return true;
        }



        private byte[] SerializeOkolina(Okolina ok)
        {


#pragma warning disable SYSLIB0011
            System.Runtime.Serialization.Formatters.Binary.BinaryFormatter bf =
                new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

            using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
            {
                bf.Serialize(ms, ok);
                return ms.ToArray();
            }
#pragma warning restore SYSLIB0011
        }

      
    }
}
