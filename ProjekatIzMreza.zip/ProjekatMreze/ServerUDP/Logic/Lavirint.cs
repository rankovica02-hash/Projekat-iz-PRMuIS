﻿using Shared.Models;

namespace ServerUDP.Logic
{
    public class Lavirint
    {
        public const int Sirina = 10;
        public const int Visina = 10;

        private Polje[,] polja;

        public Lavirint()
        {
            polja = new Polje[Visina, Sirina];
            GenerisiPrazan();
        }

        public void GenerisiPrazan()
        {
            for (int y = 0; y < Visina; y++)
            {
                for (int x = 0; x < Sirina; x++)
                {
                    polja[y, x] = new Polje(TipPolja.Prolaz, false);
                }
            }
            PostaviPrepreke();
            PostaviCiljeve();
        }
        private void PostaviPrepreke()
        {
            PostaviPrepreku(2, 0);
            PostaviPrepreku(2, 1);
            PostaviPrepreku(2, 2);
            PostaviPrepreku(2, 3);

            PostaviPrepreku(5, 4);
            PostaviPrepreku(6, 4);
            PostaviPrepreku(7, 4);

            PostaviPrepreku(4, 7);
            PostaviPrepreku(5, 7);
            PostaviPrepreku(6, 7);
        }

        private void PostaviPrepreku(int x, int y)
        {
            polja[y, x].Tip = TipPolja.Zid;
            polja[y, x].Zauzeto = false;
        }

        private void PostaviCiljeve()
        {
            //Ciljevi
            PostaviCilj(8, 8);
            PostaviCilj(1, 7);
            PostaviCilj(7, 2);
        }

        private void PostaviCilj(int x, int y)
        {
            polja[y, x].Tip = TipPolja.Cilj;
            polja[y, x].Zauzeto = false;
        }

        public bool UGranici(int x, int y)
        {
            return x >= 0 && x < Sirina && y >= 0 && y < Visina;
        }

        public Polje VratiPolje(int x, int y)
        {
            if (!UGranici(x, y))
                return null;

            return polja[y, x];
        }

        public Okolina VratiOkolinu3x3(int centerX, int centerY)
        {
            Okolina ok = new Okolina(centerX, centerY);

            for (int dy = -1; dy <= 1; dy++)
            {
                for (int dx = -1; dx <= 1; dx++)
                {
                    int x = centerX + dx;
                    int y = centerY + dy;

                    if (UGranici(x, y))
                    {
                        Polje p = VratiPolje(x, y);
                        ok.Polja[dy + 1, dx + 1] = new Polje(p.Tip, p.Zauzeto);
                    }
                    else
                    {
                        //van granica tretiramo kao prepreku
                        ok.Polja[dy + 1, dx + 1] = new Polje(TipPolja.Zid, false);
                    }
                }
            }

            return ok;
        }
        public void IspisiLavirint(Dictionary<int, Koordinate> pozicije, Dictionary<int, char> slova)
        {
            for (int y = 0; y < Visina; y++)
            {
                for (int x = 0; x < Sirina; x++)
                {
                    //prvo proveri da li je tu neka jedinka
                    char jedinkaChar = '\0';

                    foreach (var kvp in pozicije)
                    {
                        Koordinate k = kvp.Value;

                        //OBRNUT REDOSLED PROVERE
                        if (k.Y == y && k.X == x)
                        {
                            jedinkaChar = slova[kvp.Key];
                            break;
                        }
                    }


                    if (jedinkaChar != '\0')
                    {
                        Console.Write(jedinkaChar);
                        continue;
                    }

                    //ako nema jedinke, ispisi polje iz lavirinta
                    Polje p = polja[y, x];

                    if (p.Tip == TipPolja.Zid) Console.Write('#');
                    else if (p.Tip == TipPolja.Cilj) Console.Write('X');
                    else Console.Write('.');
                }
                Console.WriteLine();
            }
        }

    }
}