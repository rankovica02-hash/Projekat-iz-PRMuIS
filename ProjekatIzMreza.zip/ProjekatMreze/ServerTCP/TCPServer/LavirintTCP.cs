﻿using System;
using Shared.Models;

namespace ServerTCP
{
    public class LavirintTCP
    {
        public const int W = 10;
        public const int H = 10;

        public Polje[,] Polja;

        public LavirintTCP()
        {
            Polja = new Polje[H, W];
            InitPrazno();
        }

        private void InitPrazno()
        {
            for (int y = 0; y < H; y++)
            {
                for (int x = 0; x < W; x++)
                {
                    Polja[y, x] = new Polje(TipPolja.Prolaz, false);
                }
            }
        }

        //upisi 3x3 okolinu u poznatu mapu
        public void UpisiOkolinu(Okolina ok)
        {
            int cx = ok.CenterX;
            int cy = ok.CenterY;

            for (int dy = -1; dy <= 1; dy++)
            {
                for (int dx = -1; dx <= 1; dx++)
                {
                    int x = cx + dx;
                    int y = cy + dy;

                    if (x < 0 || x >= W || y < 0 || y >= H)
                        continue;

                    Polje izOkoline = ok.Polja[dy + 1, dx + 1];
                    if (izOkoline == null)
                        continue;

                    Polja[y, x].Tip = izOkoline.Tip;
                    Polja[y, x].Zauzeto = izOkoline.Zauzeto;
                }
            }
        }

        //prosto setovanje zauzeca na osnovu pozicija
        public void SetZauzeto(int x, int y, bool zauzeto)
        {
            if (x < 0 || x >= W || y < 0 || y >= H) return;
            Polja[y, x].Zauzeto = zauzeto;
        }

        
    }
}
