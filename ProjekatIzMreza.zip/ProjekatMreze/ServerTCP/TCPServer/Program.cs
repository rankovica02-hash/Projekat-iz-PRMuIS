﻿using System;

namespace ServerTCP
{
    class Program
    {
        static void Main(string[] args)
        {
            int port = 50005;

            TcpServer server = new TcpServer(port);
            server.Run();
        }
    }
}
