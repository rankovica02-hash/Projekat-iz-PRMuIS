﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Shared.Models;
using Shared.Net;

namespace ServerTCP
{
    public class TcpServer
    {
        private Socket listenSocket;
        private List<Socket> clients;

        private Dictionary<int, Koordinate> pozicije;              
        private Dictionary<int, Komanda> poslednjaKomanda;

        private Dictionary<int, Stack<Koordinate>> dfsPutanja;     
        private Dictionary<int, bool[,]> poseceno;                 

        private Dictionary<string, int> pronadjeniCiljevi;        
        private int ukupnoCiljeva = 3;
        private bool zavrseno = false;
        private bool krajIspisan = false;
        private LavirintTCP poznatLavirint;

        private int port;

        private int brojacPoruka = 0;

        public TcpServer(int port)
        {
            this.port = port;

            clients = new List<Socket>();
            pozicije = new Dictionary<int, Koordinate>();
            poslednjaKomanda = new Dictionary<int, Komanda>();

            dfsPutanja = new Dictionary<int, Stack<Koordinate>>();
            poseceno = new Dictionary<int, bool[,]>();
            poznatLavirint = new LavirintTCP();

            pronadjeniCiljevi = new Dictionary<string, int>();
        }

        public void Run()
        {
            listenSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            listenSocket.Bind(new IPEndPoint(IPAddress.Any, port));
            listenSocket.Listen(15);
            listenSocket.Blocking = false;

            Console.WriteLine("TCP server pokrenut na portu: " + port);

            while (true)
            {

                if (zavrseno)
                {
                    if (!krajIspisan)
                    {
                        krajIspisan = true;
                        Console.WriteLine();
                        Console.WriteLine("===== KRAJ PRETRAGE =====");
                        IspisiPronadjeneCiljeve();
                        Console.WriteLine("Simulacija je zaustavljena.");
                        Console.WriteLine("=========================");
                    }

                    Thread.Sleep(300);
                    continue;
                }

                List<Socket> readList = new List<Socket>();
                readList.Add(listenSocket);

                for (int i = 0; i < clients.Count; i++)
                    readList.Add(clients[i]);

                Socket.Select(readList, null, null, 300 * 1000);

                if (readList.Contains(listenSocket))
                {
                    PrihvatiNovogKlijenta();
                    readList.Remove(listenSocket);
                }

                for (int i = 0; i < readList.Count; i++)
                {
                    ObradiKlijenta(readList[i]);
                }

                //stampaj retko na svakih 10 poruka
               brojacPoruka++;
                if (brojacPoruka % 10 == 0)
                    IspisiStanjeJednostavno();
            }
        }

        private void PrihvatiNovogKlijenta()
        {
            try
            {
                Socket client = listenSocket.Accept();
                client.Blocking = false;
                clients.Add(client);

            }
            catch
            {
            }
        }

        private void ObradiKlijenta(Socket client)
        {
            try
            {
                object obj = BinaryNet.ReceiveObject(client);

                StatusJedinke st = obj as StatusJedinke;
                if (st != null)
                {
                    AzurirajPoziciju(st.JedinkaId, st.Pozicija.X, st.Pozicija.Y);
                    poslednjaKomanda[st.JedinkaId] = st.Komanda;

                    BinaryNet.SendObject(client, new Komanda(0, 0)); //ACK
                    return;
                }

                Okolina ok = obj as Okolina;
                if (ok == null)
                {
                    UkloniKlijenta(client);
                    return;
                }

                int id = ok.JedinkaId;
                int x = ok.CenterX;
                int y = ok.CenterY;

                UpisiOkolinuUPoznatuMapu(ok);

                AzurirajZauzeceJedinke(id, x, y);

                AzurirajPoziciju(id, x, y);


                if (ok.Polja[1, 1] != null && ok.Polja[1, 1].Tip == TipPolja.Cilj)
                {
                    string k = Key(x, y);
                    if (!pronadjeniCiljevi.ContainsKey(k))
                    {
                        pronadjeniCiljevi.Add(k, id);
                        Console.WriteLine("CILJ PRONADJEN: " + k + " (jedinka " + id + ")");
                    }
                }

                if (pronadjeniCiljevi.Count >= ukupnoCiljeva)
                {
                    zavrseno = true;
                    UkloniKlijenta(client);
                    return;
                }

                //moguci pravci iz okoline
                List<Komanda> pravci = IzracunajMogucePravce(ok);

                //DFS odluka
                Komanda cmd = OdrediKomanduDfs(id, x, y, pravci);
                poslednjaKomanda[id] = cmd;

                BinaryNet.SendObject(client, cmd);
            }
            catch
            {
                UkloniKlijenta(client);
            }
        }

        private void AzurirajPoziciju(int id, int x, int y)
        {
            if (pozicije.ContainsKey(id))
            {
                pozicije[id].X = x;
                pozicije[id].Y = y;
            }
            else
            {
                pozicije.Add(id, new Koordinate(x, y));
            }
        }

        private void UkloniKlijenta(Socket client)
        {
            for (int i = 0; i < clients.Count; i++)
            {
                if (clients[i] == client)
                {
                    clients.RemoveAt(i);
                    break;
                }
            }

            try { client.Shutdown(SocketShutdown.Both); } catch { }
            try { client.Close(); } catch { }
        }

        private List<Komanda> IzracunajMogucePravce(Okolina ok)
        {
            List<Komanda> list = new List<Komanda>();

            if (MozeNaPolje(ok.Polja[0, 1])) list.Add(new Komanda(0, -1)); //gore
            if (MozeNaPolje(ok.Polja[2, 1])) list.Add(new Komanda(0, 1));  //dole
            if (MozeNaPolje(ok.Polja[1, 0])) list.Add(new Komanda(-1, 0)); //levo
            if (MozeNaPolje(ok.Polja[1, 2])) list.Add(new Komanda(1, 0));  //desno

            return list;
        }

        private bool MozeNaPolje(Polje p)
        {
            if (p == null) return false;
            if (p.Tip == TipPolja.Zid) return false;
            if (p.Zauzeto) return false;
            return true;
        }

        private void OsigurajDfsStrukture(int id, int x, int y)
        {
            if (!poseceno.ContainsKey(id))
                poseceno.Add(id, new bool[10, 10]);

            if (!dfsPutanja.ContainsKey(id))
                dfsPutanja.Add(id, new Stack<Koordinate>());

            if (dfsPutanja[id].Count == 0)
            {
                dfsPutanja[id].Push(new Koordinate(x, y));
                poseceno[id][x, y] = true;
            }
        }

        private Komanda OdrediKomanduDfs(int id, int x, int y, List<Komanda> pravci)
        {
            OsigurajDfsStrukture(id, x, y);

            for (int i = 0; i < pravci.Count; i++)
            {
                int nx = x + pravci[i].X;
                int ny = y + pravci[i].Y;

                if (nx < 0 || nx > 9 || ny < 0 || ny > 9)
                    continue;

                if (poseceno[id][nx, ny] == false)
                {
                    poseceno[id][nx, ny] = true;
                    dfsPutanja[id].Push(new Koordinate(nx, ny));
                    return pravci[i];
                }
            }

            if (dfsPutanja[id].Count > 1)
            {
                Koordinate cur = dfsPutanja[id].Pop();
                Koordinate prev = dfsPutanja[id].Peek();

                return new Komanda(prev.X - cur.X, prev.Y - cur.Y);
            }

            return new Komanda(0, 0);
        }

        private string Key(int x, int y)
        {
            return x + "," + y;
        }

        private void IspisiPronadjeneCiljeve()
        {
            foreach (var kv in pronadjeniCiljevi)
                Console.WriteLine("Cilj " + kv.Key + " -> jedinka " + kv.Value);
        }

        private void IspisiStanjeJednostavno()
        {
            Console.WriteLine();
            Console.WriteLine("=== POZICIJE JEDINKI ===");
            foreach (var kv in pozicije)
            {
                Komanda cmd;
                if (!poslednjaKomanda.TryGetValue(kv.Key, out cmd))
                    cmd = new Komanda(0, 0);

                Console.WriteLine("ID=" + kv.Key +
                                  "  Pos=(" + kv.Value.X + "," + kv.Value.Y + ")" +
                                  "  Sledeci=(" + cmd.X + "," + cmd.Y + ")");
            }
            Console.WriteLine("Pronadjeni ciljevi: " + pronadjeniCiljevi.Count + "/" + ukupnoCiljeva);
        }

        private void AzurirajZauzeceJedinke(int id, int noviX, int noviY)
        {
            //ocisti staru poziciju ako postoji
            if (pozicije.ContainsKey(id))
            {
                int stariX = pozicije[id].X;
                int stariY = pozicije[id].Y;
                poznatLavirint.SetZauzeto(stariX, stariY, false);
            }

            //postavi novu poziciju kao zauzetu
            poznatLavirint.SetZauzeto(noviX, noviY, true);
        }

        private void UpisiOkolinuUPoznatuMapu(Okolina ok)
        {
            poznatLavirint.UpisiOkolinu(ok);

        }

    }
}
