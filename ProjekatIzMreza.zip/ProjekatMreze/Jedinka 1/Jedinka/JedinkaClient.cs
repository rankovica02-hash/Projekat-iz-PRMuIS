﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using Shared.Models;
using Shared.Net;

namespace Jedinka
{
    public class JedinkaClient
    {
        private int id;
        private int x;
        private int y;

        private string udpIp;
        private int udpPort;

        private string tcpIp;
        private int tcpPort;

        private Socket udpSocket;
        private EndPoint udpServerEP;

        private Socket tcpSocket;

        public JedinkaClient(int id, int x, int y, string udpIp, int udpPort, string tcpIp, int tcpPort)
        {
            this.id = id;
            this.x = x;
            this.y = y;

            this.udpIp = udpIp;
            this.udpPort = udpPort;

            this.tcpIp = tcpIp;
            this.tcpPort = tcpPort;
        }

        public void Run()
        {
            Console.WriteLine("Jedinka ID=" + id + " startuje na (" + x + "," + y + ")");

            //UDP
            udpSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            udpSocket.Blocking = false;
            udpServerEP = new IPEndPoint(IPAddress.Parse(udpIp), udpPort);

            //TCP
            tcpSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            tcpSocket.Connect(new IPEndPoint(IPAddress.Parse(tcpIp), tcpPort));
            tcpSocket.Blocking = false;

            bool kraj = false;

            while (!kraj)
            {
                //3x3
                PosaljiUdpZahtevZaOkolinu();

                Okolina ok = CekajUdpOkolinu();
                if (ok == null)
                {
                    Console.WriteLine("Nisam dobio okolinu (UDP).");
                    continue;
                }
                //okolina pripada jedinki sa ovim idem 
                ok.JedinkaId = id;
                if (ok.Polja[1, 1] != null)
                    ok.Polja[1, 1].Zauzeto = true;

                bool okTcp = PosaljiTcpOkolinu(ok);
                if (!okTcp)
                {
                    Console.WriteLine("KRAJ - TCP server je zatvorio konekciju.");
                    break;
                }

                Komanda cmd = CekajTcpKomandu();
                if (cmd == null)
                {
                    Console.WriteLine("KRAJ - TCP server ne salje vise komande.");
                    break;
                }

                Console.WriteLine("Poz=(" + x + "," + y + ") | Komanda=(" + cmd.X + "," + cmd.Y + ")");

                //kretanje
                x = x + cmd.X;
                y = y + cmd.Y;

                //novi status, nakon pomeranja
                StatusJedinke st = new StatusJedinke(id, x, y, cmd);

                if (!PosaljiTcpStatus(st))
                {
                    Console.WriteLine("KRAJ - TCP server je zatvorio konekciju (status).");
                    break;
                }

                //potvrda primanja poruke o pomeranju
                object ack = CekajTcpAck();
                if (ack == null)
                {
                    Console.WriteLine("KRAJ - nema ACK od servera.");
                    break;
                }

                Thread.Sleep(200);
            }

            ZatvoriSve();
            Console.WriteLine("Jedinka zavrsila. Enter...");
            Console.ReadLine();
        }

        private void PosaljiUdpZahtevZaOkolinu()
        {
            string poruka = id + " " + x + " " + y;
            byte[] data = Encoding.UTF8.GetBytes(poruka);

            try
            {
                udpSocket.SendTo(data, udpServerEP);
            }
            catch
            {
            }
        }

        private Okolina CekajUdpOkolinu()
        {
            // multiplex: cekamo da UDP bude citljiv (i TCP moze biti citljiv ali nas sad zanima UDP)
            DateTime start = DateTime.Now;

            while (true)
            {
                if ((DateTime.Now - start).TotalSeconds > 3)
                    return null;

                List<Socket> readList = new List<Socket>();
                readList.Add(udpSocket);
                readList.Add(tcpSocket);

                Socket.Select(readList, null, null, 200 * 1000);

                if (readList.Contains(udpSocket))
                {
                    byte[] buffer = new byte[4096];
                    EndPoint from = new IPEndPoint(IPAddress.Any, 0);

                    try
                    {
                        int bytes = udpSocket.ReceiveFrom(buffer, ref from);

#pragma warning disable SYSLIB0011
                        BinaryFormatter bf = new BinaryFormatter();
                        using (MemoryStream ms = new MemoryStream(buffer, 0, bytes))
                        {
                            Okolina ok = (Okolina)bf.Deserialize(ms);
                            return ok;
                        }
#pragma warning restore SYSLIB0011
                    }
                    catch
                    {
                        // probaj opet
                    }
                }

                // malo spusti CPU
                Thread.Sleep(5);
            }
        }

        private bool PosaljiTcpOkolinu(Okolina ok)
        {
            try
            {
                BinaryNet.SendObject(tcpSocket, ok);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private Komanda CekajTcpKomandu()
        {
            DateTime start = DateTime.Now;

            while (true)
            {
                if ((DateTime.Now - start).TotalSeconds > 3)
                    return null;

                List<Socket> readList = new List<Socket>();
                readList.Add(udpSocket);
                readList.Add(tcpSocket);

                Socket.Select(readList, null, null, 200 * 1000);

                if (readList.Contains(tcpSocket))
                {
                    try
                    {
                        object obj = BinaryNet.ReceiveObject(tcpSocket);
                        return obj as Komanda;
                    }
                    catch
                    {
                        return null;
                    }
                }

                Thread.Sleep(5);
            }
        }

        private bool PosaljiTcpStatus(StatusJedinke st)
        {
            try
            {
                BinaryNet.SendObject(tcpSocket, st);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private object CekajTcpAck()
        {
            DateTime start = DateTime.Now;

            while (true)
            {
                if ((DateTime.Now - start).TotalSeconds > 3)
                    return null;
                //Jedan thread prati više socketa bez blokiranja.
                List<Socket> readList = new List<Socket>();
                readList.Add(udpSocket);
                readList.Add(tcpSocket);

                Socket.Select(readList, null, null, 200 * 1000);

                if (readList.Contains(tcpSocket))
                {
                    try
                    {
                        return BinaryNet.ReceiveObject(tcpSocket); // ACK je Komanda(0,0)
                    }
                    catch
                    {
                        return null;
                    }
                }

                Thread.Sleep(5);
            }
        }

        private void ZatvoriSve()
        {
            try { tcpSocket.Shutdown(SocketShutdown.Both); } catch { }
            try { tcpSocket.Close(); } catch { }

            try { udpSocket.Close(); } catch { }
        }
    }
}
