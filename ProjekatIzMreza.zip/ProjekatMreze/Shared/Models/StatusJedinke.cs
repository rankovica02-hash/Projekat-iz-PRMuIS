﻿using System;

namespace Shared.Models
{
    [Serializable]
    public class StatusJedinke
    {
        public int JedinkaId { get; set; }
        public Koordinate Pozicija { get; set; }
        public Komanda Komanda { get; set; }

        public StatusJedinke()
        {
            Pozicija = new Koordinate();
            Komanda = new Komanda();
        }

        public StatusJedinke(int id, int x, int y, Komanda cmd)
        {
            JedinkaId = id;
            Pozicija = new Koordinate(x, y);
            Komanda = cmd;
        }
    }
}
