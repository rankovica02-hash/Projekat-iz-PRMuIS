﻿using System;

namespace Shared.Models
{
    [Serializable]
    public class Okolina
    {
        //gde se nalazi centar okoline u velikom lavirintu (10x10)
        public int CenterX { get; set; }
        public int CenterY { get; set; }
        public int JedinkaId { get; set; }

        //3x3 polja oko jedinke
        public Polje[,] Polja { get; set; }

        public Okolina()
        {
            Polja = new Polje[3, 3];
            PopuniPrazno();
        }

        public Okolina(int centerX, int centerY)
        {
            CenterX = centerX;
            CenterY = centerY;
            Polja = new Polje[3, 3];
            PopuniPrazno();
        }

        private void PopuniPrazno()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Polja[i, j] = new Polje(TipPolja.Prolaz, false);
                }
            }
        }
    }
}
