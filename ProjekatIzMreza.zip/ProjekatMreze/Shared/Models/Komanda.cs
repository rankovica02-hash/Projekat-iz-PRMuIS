﻿using System;

namespace Shared.Models
{
    [Serializable]
    public class Komanda
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Komanda()
        {
            X = 0;
            Y = 0;
        }

        public Komanda(int x, int y)
        {
            if (x < -1) x = -1;
            if (x > 1) x = 1;
            if (y < -1) y = -1;
            if (y > 1) y = 1;

            X = x;
            Y = y;
        }

        public override string ToString()
        {
            return "Pomeri: (" + X + ", " + Y + ")";
        }
    }
}
