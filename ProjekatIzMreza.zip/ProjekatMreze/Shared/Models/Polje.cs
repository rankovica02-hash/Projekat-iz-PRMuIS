﻿namespace Shared.Models
{
    public enum TipPolja
    {
        Pocetak,
        Zid,
        Cilj,
        Prolaz
    }

    [System.Serializable]
    public class Polje
    {
        public TipPolja Tip { get; set; }
        public bool Zauzeto { get; set; }

        public Polje()
        {
            Tip = TipPolja.Prolaz;
            Zauzeto = false;
        }

        public Polje(TipPolja tip, bool zauzeto)
        {
            Tip = tip;
            Zauzeto = zauzeto;
        }

        public override string ToString()
        {
            return Tip.ToString() + " " + (Zauzeto ? "Z" : "N");
        }
    }
}
