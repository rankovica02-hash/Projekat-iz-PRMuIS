﻿namespace Shared.Models
{
    [System.Serializable]
    public class Koordinate
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Koordinate() { }

        public Koordinate(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}
