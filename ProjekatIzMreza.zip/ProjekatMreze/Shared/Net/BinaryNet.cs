﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;

namespace Shared.Net
{
    public class BinaryNet
    {
        //pravimo svoj format
        public static void SendObject(Socket socket, object obj)
        {
            byte[] data = Serialize(obj);

            //prvo saljemo duzinu 4 bajta
            byte[] lenBytes = BitConverter.GetBytes(data.Length);
            socket.Send(lenBytes);

            socket.Send(data);
        }

        public static object ReceiveObject(Socket socket)
        {
            //procitaj 4 bajta duzine
            byte[] lenBytes = ReceiveExact(socket, 4);
            int len = BitConverter.ToInt32(lenBytes, 0);

            //procitaj tacno len bajtova
            byte[] data = ReceiveExact(socket, len);

            return Deserialize(data);
        }

        private static byte[] ReceiveExact(Socket socket, int count)
        {
            byte[] buffer = new byte[count];
            int received = 0;

            while (received < count)
            {
                while (!socket.Poll(100 * 1000, SelectMode.SelectRead)) //nije spreman za citanje
                    Thread.Sleep(1);

                int r = socket.Receive(buffer, received, count - received, SocketFlags.None);
                if (r == 0) throw new Exception("Konekcija prekinuta.");
                received += r;
            }
            return buffer;
        }




        private static byte[] Serialize(object obj)
        {
#pragma warning disable SYSLIB0011
            BinaryFormatter bf = new BinaryFormatter();
            using (MemoryStream ms = new MemoryStream())
            {
                bf.Serialize(ms, obj);
                return ms.ToArray();
            }
#pragma warning restore SYSLIB0011
        }

        private static object Deserialize(byte[] data)
        {
#pragma warning disable SYSLIB0011
            BinaryFormatter bf = new BinaryFormatter();
            using (MemoryStream ms = new MemoryStream(data))
            {
                return bf.Deserialize(ms);
            }
#pragma warning restore SYSLIB0011
        }
    }
}
